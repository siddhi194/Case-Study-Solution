-- Database Schema

-- places dataset
DROP TABLE IF EXISTS codetest.places;

CREATE TABLE codetest.places (
    city VARCHAR(85) NOT NULL, 
    county VARCHAR(85) NOT NULL, 
    country VARCHAR(56) NOT NULL,
    UNIQUE KEY (city, county, country)			-- uniquely identify data
);

-- people dataset
DROP TABLE IF EXISTS codetest.people;

CREATE TABLE codetest.people (
    given_name VARCHAR(32) NOT NULL,
    family_name VARCHAR(64) NOT NULL,
    date_of_birth DATE NOT NULL,
    place_of_birth VARCHAR(85) NOT NULL,
    FOREIGN KEY (place_of_birth) REFERENCES places(city)
);

