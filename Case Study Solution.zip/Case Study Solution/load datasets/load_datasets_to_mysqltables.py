#!/usr/bin/env python

#interact with the native OS Python(to access environment variables)
import os

#to extract data files from csv to read and load
import csv

#helps to communicate between python code and database
import sqlalchemy


#using db connection details from docker
db_name = os.environ.get("MYSQL_DATABASE")
user = os.environ.get("MYSQL_USER")
password = os.environ.get("MYSQL_PASSWORD")
    
    #f-string used to format message while concatenating
connection_str = f"mysql+pymysql://{user}:{password}@localhost:3306/{db_name}"
    
# Connect to database
engine = sqlalchemy.create_engine(connection_str)
connection = engine.connect()

    #f-string used to format message while concatenating
print(f"Connection created successfully.")

#Metadata to describe the structure of the database in terms of python datastructures
metadata = sqlalchemy.schema.MetaData(engine)


#ORM object to refer to the respective table
Places = sqlalchemy.schema.Table('places', metadata, autoload=True, autoload_with=engine)
People = sqlalchemy.schema.Table('people', metadata, autoload=True, autoload_with=engine)

#Read csv from python
with open('data/places.csv') as csv_file:
  reader = csv.reader(csv_file)
  next(reader)
  for row in reader: 
    connection.execute(Places.insert().values(name = row[0]))
    
with open('data/people.csv') as csv_file:
  reader = csv.reader(csv_file)
  next(reader)
  for row in reader: 
    connection.execute(People.insert().values(name = row[0]))

