-- Returns countries and their population

SELECT
  country, COUNT(*) as population
FROM
  codetest.people JOIN codetest.places 
  ON people.place_of_birth = places.city
  GROUP BY country
;