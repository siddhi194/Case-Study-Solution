#!/usr/bin/env python

import json
import sqlalchemy
import os

#using db connection details from docker
db_name = os.environ.get("MYSQL_DATABASE")
user = os.environ.get("MYSQL_USER")
password = os.environ.get("MYSQL_PASSWORD")
    
    #f-string used to format message while concatenating
connection_str = f"mysql+pymysql://{user}:{password}@localhost:3306/{db_name}"
    
# Connect to database
engine = sqlalchemy.create_engine(connection_str)
connection = engine.connect()

    #f-string used to format message while concatenating
print(f"Connection created successfully.")

#writing to json file
with open('/data/summary_count.json', 'w') as json_file:
 c = connection.cursor()
c.execute("SELECT country, COUNT(*) as population FROM codetest.people JOIN codetest.places  ON people.place_of_birth = places.city GROUP BY country")
rows = c.fetchall()

rows = [{'country': row[0], 'population': row[1]} for row in rows]
json.dump(rows, json_file, separators=(',', ':'))

connection.close()